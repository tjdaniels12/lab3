﻿Option Strict On

Public Class frmAverageUnitsShipped

    Dim arrayNumbers(6) As Double ' Array size
    Dim days As Integer = 1       ' variable for days, set to 1 to start
    Dim sum As Double           ' variable for total, used for sum of array
    Dim average As Double         ' variable for average, used to calculate average of the array elements
    Dim userInput As Double       ' variable to hold user input, to be parsed
    Dim validInput As Double
    Dim errorMessage As String
    Dim employee As Integer = 0
    Dim employeeUnits(2, 6) As Double
    Dim total As Double






    Public Function validation(ByVal userInput As String) As Boolean                    'validation function, takes user's input and will output a true or false, determining if it is valid or not
        If (Double.TryParse(userInput, validInput)) = False Then                        'checks if user input is a numeric value
            errorMessage = "Please ensure your input is a number!"                      'if it isn't, it sets the appropriate error message and
            validation = False                                                          'sets valid state to false
        ElseIf ((validInput >= 0) AndAlso (validInput <= 1000)) = False Then             'if the value is numeric it will then check if it is within the desired range
            errorMessage = "Please ensure your input is between 0 and 1000 inclusive!"   'if it isn't, it sets the appropriate error message and
            validation = False                                                          'sets valid state to false
        Else validation = True                                                          'otherwise, it is a valid entry
        End If
        Return validation
    End Function



    Private Sub frmAverageUnitsShipped_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        txtUnits.Clear() ' clears txtUnits
        lblDays.Text = "Day: 1" ' change lbldays display back to default
        txtOutput.Clear() ' clear output textbox
        lblOutput.Text = "" ' clear output label
        btnEnter.Enabled = True ' enable btnEnter
        txtUnits.Enabled = True ' enable txtUnits
        txtUnits.Focus() ' shift focus to txtUnits for user to easily enter more information
        sum = 0 'reset total in case of form reset
        average = 0
        lblOutput2.Text = "" ' clear output label
        lblOutput3.Text = "" ' clear output label
        txtOutput2.Clear() ' clear output textbox
        txtOutput3.Clear() ' clear output textbox
        employee = 0
        total = 0
        days = 1



    End Sub

    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click

        If employee = 0 Then

            If validation(txtUnits.Text) = True Then
                employeeUnits(employee, days - 1) = validInput
                days += 1
                txtOutput.AppendText(validInput & vbCrLf)
                txtUnits.Clear() ' clear user entry
                lblDays.Text = "&Day: " & days ' display newly incremented day
                If days = 8 Then
                    For i As Integer = 0 To 6
                        sum += employeeUnits(employee, i)
                    Next i
                    average = sum / 7
                    total += average
                    Dim averageString = average.ToString("0.00")
                    lblOutput.Text = "The average across 7 days is: " & averageString
                    employee += 1
                    days = 1
                    average = 0
                    sum = 0
                End If
            Else MessageBox.Show(errorMessage)
                txtUnits.Clear()
                txtUnits.Focus()
            End If

        ElseIf employee = 1 Then

            If validation(txtUnits.Text) Then
                employeeUnits(employee, days - 1) = validInput
                days += 1
                txtOutput2.AppendText(validInput & vbCrLf)
                txtUnits.Clear() ' clear user entry
                lblDays.Text = "&Day: " & days ' display newly incremented day
                If days = 8 Then
                    For i As Integer = 0 To 6
                        sum += employeeUnits(employee, i)
                    Next i
                    average = sum / 7
                    total += average
                    Dim averageString = average.ToString("0.00")
                    lblOutput2.Text = "The average across 7 days is: " & averageString
                    employee += 1
                    days = 1
                    average = 0
                    sum = 0
                End If
            Else MessageBox.Show(errorMessage)
                txtUnits.Clear()
                txtUnits.Focus()
            End If

        ElseIf employee = 2 Then

            If validation(txtUnits.Text) Then
                employeeUnits(employee, days - 1) = validInput
                days += 1
                txtOutput3.AppendText(validInput & vbCrLf)
                txtUnits.Clear() ' clear user entry
                lblDays.Text = "&Day: " & days ' display newly incremented day
                If days = 8 Then
                    For i As Integer = 0 To 6
                        sum += employeeUnits(employee, i)
                    Next i
                    average = sum / 7
                    total += average
                    Dim averageString = average.ToString("0.00")
                    lblOutput3.Text = "The average across 7 days is: " & averageString
                    employee += 1
                    days = 1
                    average = 0
                    sum = 0
                End If
            Else MessageBox.Show(errorMessage)
                txtUnits.Clear()
                txtUnits.Focus()
            End If
        End If
        If employee = 3 Then
            Debug.Write("the total is: " & total)
            total = total / 3
            lblAverage.Text = "The total average across all 3 employees is: " & total
            btnEnter.Enabled = False ' disable enter button
            txtUnits.Enabled = False ' disable user entry
        End If

        ' If idk Then
        ' else MessageBox.Show(errorMessage)
        ' txtUnits.Clear()
        ' txtUnits.Focus()
        '  End If

        'arrayNumbers(days - 1) = Convert.ToDouble(txtUnits.Text) ' store user entered units into array

        'days += 1 ' increment days

        'txtOutput.AppendText(txtUnits.Text & vbCrLf) ' display units on multiple lines

        'txtUnits.Clear() ' clear user entry

        'lblDays.Text = "&Day: " & days ' display newly incremented day

        'If days = 8 Then 'when max days is reached and average calculation is displayed
        'For arrayvalue As Integer = 0 To 6 ' cycle through array elements

        'total += arrayNumbers(arrayvalue) ' add each element of array together


        'Next arrayvalue
        'average = total / 7 ' calculate average of array elements
        'Dim averageString = average.ToString("0.00") ' display average with 2 decimal places
        'lblOutput.Text = "The average across 7 days is: " & averageString ' display calculated average
        'btnEnter.Enabled = False ' disable enter button
        'txtUnits.Enabled = False ' disable user entry
        'lblDays.Text = "&Day: 7" ' keep day label set at 7
        'days = 1 ' reset days in case of form reset


    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Application.Exit() ' exit form

    End Sub
End Class
