﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAverageUnitsShipped
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblUnits = New System.Windows.Forms.Label()
        Me.txtUnits = New System.Windows.Forms.TextBox()
        Me.lblDays = New System.Windows.Forms.Label()
        Me.lblOutput = New System.Windows.Forms.Label()
        Me.btnEnter = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.txtOutput = New System.Windows.Forms.TextBox()
        Me.AverageUnitsTooltip = New System.Windows.Forms.ToolTip(Me.components)
        Me.lblEmployee1 = New System.Windows.Forms.Label()
        Me.lblEmployee2 = New System.Windows.Forms.Label()
        Me.lblEmployee3 = New System.Windows.Forms.Label()
        Me.txtOutput2 = New System.Windows.Forms.TextBox()
        Me.lblOutput2 = New System.Windows.Forms.Label()
        Me.txtOutput3 = New System.Windows.Forms.TextBox()
        Me.lblOutput3 = New System.Windows.Forms.Label()
        Me.lblAverage = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblUnits
        '
        Me.lblUnits.AutoSize = True
        Me.lblUnits.Location = New System.Drawing.Point(49, 56)
        Me.lblUnits.Name = "lblUnits"
        Me.lblUnits.Size = New System.Drawing.Size(40, 17)
        Me.lblUnits.TabIndex = 1
        Me.lblUnits.Text = "&Units"
        Me.lblUnits.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtUnits
        '
        Me.txtUnits.Location = New System.Drawing.Point(95, 56)
        Me.txtUnits.Name = "txtUnits"
        Me.txtUnits.Size = New System.Drawing.Size(79, 22)
        Me.txtUnits.TabIndex = 2
        Me.AverageUnitsTooltip.SetToolTip(Me.txtUnits, "Enter a valid number of units")
        '
        'lblDays
        '
        Me.lblDays.AutoSize = True
        Me.lblDays.Location = New System.Drawing.Point(49, 16)
        Me.lblDays.Name = "lblDays"
        Me.lblDays.Size = New System.Drawing.Size(53, 17)
        Me.lblDays.TabIndex = 0
        Me.lblDays.Text = "&Day: 1 "
        Me.lblDays.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblOutput
        '
        Me.lblOutput.BackColor = System.Drawing.SystemColors.Info
        Me.lblOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOutput.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblOutput.Location = New System.Drawing.Point(52, 261)
        Me.lblOutput.Name = "lblOutput"
        Me.lblOutput.Size = New System.Drawing.Size(150, 34)
        Me.lblOutput.TabIndex = 9
        Me.lblOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.AverageUnitsTooltip.SetToolTip(Me.lblOutput, "The average for Employee 1")
        '
        'btnEnter
        '
        Me.btnEnter.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnEnter.Location = New System.Drawing.Point(55, 352)
        Me.btnEnter.Name = "btnEnter"
        Me.btnEnter.Size = New System.Drawing.Size(148, 33)
        Me.btnEnter.TabIndex = 13
        Me.btnEnter.Text = "&Enter"
        Me.AverageUnitsTooltip.SetToolTip(Me.btnEnter, "Click to enter your data")
        Me.btnEnter.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnReset.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnReset.Location = New System.Drawing.Point(207, 352)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(148, 33)
        Me.btnReset.TabIndex = 14
        Me.btnReset.Text = "&Reset"
        Me.AverageUnitsTooltip.SetToolTip(Me.btnReset, "Click to reset this form")
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnExit.Location = New System.Drawing.Point(359, 352)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(148, 33)
        Me.btnExit.TabIndex = 15
        Me.btnExit.Text = "E&xit"
        Me.AverageUnitsTooltip.SetToolTip(Me.btnExit, "Click to exit")
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'txtOutput
        '
        Me.txtOutput.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txtOutput.Location = New System.Drawing.Point(52, 108)
        Me.txtOutput.Multiline = True
        Me.txtOutput.Name = "txtOutput"
        Me.txtOutput.ReadOnly = True
        Me.txtOutput.Size = New System.Drawing.Size(150, 150)
        Me.txtOutput.TabIndex = 6
        Me.AverageUnitsTooltip.SetToolTip(Me.txtOutput, "This is where your previously entered units are displayed")
        '
        'lblEmployee1
        '
        Me.lblEmployee1.Location = New System.Drawing.Point(48, 88)
        Me.lblEmployee1.Name = "lblEmployee1"
        Me.lblEmployee1.Size = New System.Drawing.Size(100, 17)
        Me.lblEmployee1.TabIndex = 3
        Me.lblEmployee1.Text = "Employee &1"
        '
        'lblEmployee2
        '
        Me.lblEmployee2.Location = New System.Drawing.Point(203, 88)
        Me.lblEmployee2.Name = "lblEmployee2"
        Me.lblEmployee2.Size = New System.Drawing.Size(101, 17)
        Me.lblEmployee2.TabIndex = 4
        Me.lblEmployee2.Text = "Employee &2"
        '
        'lblEmployee3
        '
        Me.lblEmployee3.Location = New System.Drawing.Point(359, 88)
        Me.lblEmployee3.Name = "lblEmployee3"
        Me.lblEmployee3.Size = New System.Drawing.Size(94, 17)
        Me.lblEmployee3.TabIndex = 5
        Me.lblEmployee3.Text = "Employee &3"
        '
        'txtOutput2
        '
        Me.txtOutput2.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txtOutput2.Location = New System.Drawing.Point(207, 108)
        Me.txtOutput2.Multiline = True
        Me.txtOutput2.Name = "txtOutput2"
        Me.txtOutput2.ReadOnly = True
        Me.txtOutput2.Size = New System.Drawing.Size(150, 150)
        Me.txtOutput2.TabIndex = 7
        Me.AverageUnitsTooltip.SetToolTip(Me.txtOutput2, "This is where your previously entered units are displayed")
        '
        'lblOutput2
        '
        Me.lblOutput2.BackColor = System.Drawing.SystemColors.Info
        Me.lblOutput2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOutput2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblOutput2.Location = New System.Drawing.Point(207, 261)
        Me.lblOutput2.Name = "lblOutput2"
        Me.lblOutput2.Size = New System.Drawing.Size(150, 34)
        Me.lblOutput2.TabIndex = 10
        Me.lblOutput2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.AverageUnitsTooltip.SetToolTip(Me.lblOutput2, "The average for Employee 2")
        '
        'txtOutput3
        '
        Me.txtOutput3.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txtOutput3.Location = New System.Drawing.Point(362, 108)
        Me.txtOutput3.Multiline = True
        Me.txtOutput3.Name = "txtOutput3"
        Me.txtOutput3.ReadOnly = True
        Me.txtOutput3.Size = New System.Drawing.Size(150, 150)
        Me.txtOutput3.TabIndex = 8
        Me.AverageUnitsTooltip.SetToolTip(Me.txtOutput3, "This is where your previously entered units are displayed")
        '
        'lblOutput3
        '
        Me.lblOutput3.BackColor = System.Drawing.SystemColors.Info
        Me.lblOutput3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOutput3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblOutput3.Location = New System.Drawing.Point(362, 261)
        Me.lblOutput3.Name = "lblOutput3"
        Me.lblOutput3.Size = New System.Drawing.Size(150, 34)
        Me.lblOutput3.TabIndex = 11
        Me.lblOutput3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.AverageUnitsTooltip.SetToolTip(Me.lblOutput3, "The average for Employee 3")
        '
        'lblAverage
        '
        Me.lblAverage.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.lblAverage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAverage.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblAverage.Location = New System.Drawing.Point(52, 304)
        Me.lblAverage.Name = "lblAverage"
        Me.lblAverage.Size = New System.Drawing.Size(461, 34)
        Me.lblAverage.TabIndex = 12
        Me.lblAverage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.AverageUnitsTooltip.SetToolTip(Me.lblAverage, "The calculated average of units across all employees")
        '
        'frmAverageUnitsShipped
        '
        Me.AcceptButton = Me.btnEnter
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnReset
        Me.ClientSize = New System.Drawing.Size(562, 400)
        Me.Controls.Add(Me.lblAverage)
        Me.Controls.Add(Me.txtOutput3)
        Me.Controls.Add(Me.lblOutput3)
        Me.Controls.Add(Me.txtOutput2)
        Me.Controls.Add(Me.lblOutput2)
        Me.Controls.Add(Me.lblEmployee3)
        Me.Controls.Add(Me.lblEmployee2)
        Me.Controls.Add(Me.lblEmployee1)
        Me.Controls.Add(Me.txtOutput)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnEnter)
        Me.Controls.Add(Me.lblOutput)
        Me.Controls.Add(Me.lblDays)
        Me.Controls.Add(Me.txtUnits)
        Me.Controls.Add(Me.lblUnits)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmAverageUnitsShipped"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Average Units Shipped by Employee"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblUnits As Label
    Friend WithEvents txtUnits As TextBox
    Friend WithEvents lblDays As Label
    Friend WithEvents lblOutput As Label
    Friend WithEvents btnEnter As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents txtOutput As TextBox
    Friend WithEvents AverageUnitsTooltip As ToolTip
    Friend WithEvents lblEmployee1 As Label
    Friend WithEvents lblEmployee2 As Label
    Friend WithEvents lblEmployee3 As Label
    Friend WithEvents txtOutput2 As TextBox
    Friend WithEvents lblOutput2 As Label
    Friend WithEvents txtOutput3 As TextBox
    Friend WithEvents lblOutput3 As Label
    Friend WithEvents lblAverage As Label
End Class
